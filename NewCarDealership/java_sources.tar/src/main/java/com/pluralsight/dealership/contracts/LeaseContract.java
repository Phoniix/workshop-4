package com.pluralsight.dealership.contracts;

import com.pluralsight.roadVehicle.Vehicle;

public class LeaseContract extends Contract {


    public LeaseContract(String date, String customerName, String customerEmail, Vehicle soldVehicle, SoldStatus sold, int numberOfPayment) {
        super(date, customerName, customerEmail, soldVehicle, sold, numberOfPayment);
    }

    protected SoldStatus getSoldStatus() {
        return this.sold == SoldStatus.SOLD ? SoldStatus.SOLD : SoldStatus.NOT_SOLD;
    }

    protected double getTotalPrice() {
        return 0;
    }

    protected double getMonthlyPayment() {
        return 0;
    }
}
