package com.pluralsight.dealership.contracts;

import com.pluralsight.roadVehicle.Vehicle;

public class SalesContract extends Contract {
    private final double SALES_TAX = this.totalPrice * .05;
    private final double RECORDING_FEE = 100.00;
    private final double PROCESSING_FEE = this.vehicle.getPrice() < 10000 ? 295.00 : 495.00;


    public SalesContract(String date, String customerName, String customerEmail, Vehicle soldVehicle, SoldStatus sold, double totalPrice, int numberOfPayments) {
        super(date, customerName, customerEmail, soldVehicle, sold, numberOfPayments);
    }

    protected SoldStatus getSoldStatus() {
        return this.sold;
    }
    protected double getTotalPrice() {
        return this.vehicle.getPrice();
    }
    protected double getMonthlyPayment() {
        return 0;
    }
}
