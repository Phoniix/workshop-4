package com.pluralsight.dealership.contracts;

import com.pluralsight.roadVehicle.Vehicle;

abstract class Contract {
    protected String date = null;
    protected String customerName = null;
    protected String customerEmail = null;
    protected Vehicle vehicle = null;
    protected SoldStatus sold = null;
    protected double totalPrice = 0;
    protected double monthlyPayment = 0;

    protected Contract(String date, String customerName, String customerEmail, Vehicle vehicle, SoldStatus sold, int numberOfPayments) {
        this.date = date;
        this.customerName = customerName;
        this.customerEmail = customerEmail;
        this.vehicle = vehicle;
        this.sold = sold;
        this.totalPrice = this.vehicle.getPrice();
        this.monthlyPayment = this.getTotalPrice() / numberOfPayments;
    }

    protected String getDate() {
        return this.date;
    };
    protected String getCustomerName() {
        return this.customerName;
    };
    protected String getCustomerEmail() {
        return this.customerEmail;
    };

    protected abstract SoldStatus getSoldStatus ();
    protected abstract double getTotalPrice();
    protected abstract double getMonthlyPayment();


}
